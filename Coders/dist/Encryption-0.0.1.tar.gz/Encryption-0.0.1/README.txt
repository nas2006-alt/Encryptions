Ver 0.0.1:
	Contains Caesar Cipher, Vigenere, Pig Latin, and Morse Code


Email me at nasiegel8@gmail.com if you have a suggestion.